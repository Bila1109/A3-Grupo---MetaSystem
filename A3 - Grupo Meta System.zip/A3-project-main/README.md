# A3-project
Neste projeto de gerenciamento foi desenvolvido o conceito básico de gerenciamento de informações dentro de um sistema.
Em nosso projeto realizamos um CRUD, termo comumente utilizado no meio da programação é um acrônimo para as maneiras de se operar em informação armazenada originário do inglês permite ao usuário realizar operações como criar(create) e inserir informações em um banco de dados, ler(read) informações presentes no banco, atualizar(update) informações do banco de dados e por fim deletar(delete) as informações também presentes no banco.

----------------------------------------------------------------------------------------------------

In this management project, the basic concept of managing information within a system was developed.
In our project we carried out a CRUD, a term commonly used in the middle of programming is an acronym for the ways of operating on stored information, originating in English, it allows the user to perform operations such as create(create) and insert information into a database, read( read) information present in the database, update (update) information from the database and finally delete (delete) the information also present in the database.
